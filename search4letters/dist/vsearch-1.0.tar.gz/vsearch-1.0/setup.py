from pip._vendor.chardet.cli.chardetect import description_of
from setuptools import setup

setup(
    name='vsearch',
    version='1.0',
    description='search tool',
    author='sriram',
    author_email='dummy@summy.com',
    py_modules=['vsearch'],
)
